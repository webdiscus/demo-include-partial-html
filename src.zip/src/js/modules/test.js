(function ($) {
  "use strict";

  $(document).ready(function () {
    console.log("jQuery is working!");

    $("body").css("background-color", "green");
  });
})(jQuery);
